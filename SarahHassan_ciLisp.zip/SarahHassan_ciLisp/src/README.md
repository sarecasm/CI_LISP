ciLisp Project

/**
* Name: Sarah Hassan
* Lab: ciLisp
* Due: December 5, 2019
**/

Task 1 Submission
* Completed TODO Tasks for Task 1 *
* No issues were found *


Sample Tests
*"/Users/SarahHassan/Desktop/COMP 232/SarahHassan_ciLisp/cmake-build-debug/cilisp"

> (add 1 2)
Type: 0
Data: 3.000000

>  (sub 6 5)
Type: 0
Data: 1.000000

>  (div 6 3)
Type: 0
Data: 2.000000
*
